from flask import Flask, render_template, redirect, url_for, request, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
from werkzeug.utils import secure_filename
from functools import wraps
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, IntegerField, SelectField, DateField, FileField, EmailField
from wtforms.validators import DataRequired, Email, Optional, Length, NumberRange
from flask_migrate import Migrate

app = Flask(__name__)
app.config['SECRET_KEY'] = 'sua-chave-secreta-aqui'  # Em produção, use uma chave segura e variável de ambiente
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///bombeiro_mirim.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(app.static_folder, 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max-limit

# Configurações para upload de arquivos
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_photo(photo, folder='alunos'):
    if photo and allowed_file(photo.filename):
        try:
            filename = secure_filename(photo.filename)
            # Gera um nome único para o arquivo
            unique_filename = f"{folder}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{filename}"
            
            # Cria o diretório se não existir
            upload_folder = os.path.join(app.root_path, app.config['UPLOAD_FOLDER'], folder)
            os.makedirs(upload_folder, exist_ok=True)
            print(f"Diretório de upload: {upload_folder}")
            
            # Caminho completo do arquivo
            photo_path = os.path.join(upload_folder, unique_filename)
            # Caminho relativo para o banco de dados (usando sempre forward slashes)
            relative_path = '/'.join(['uploads', folder, unique_filename])
            
            # Salva o arquivo
            photo.save(photo_path)
            print(f"Foto salva com sucesso em: {photo_path}")
            print(f"Caminho relativo salvo no banco: {relative_path}")
            
            return relative_path
        except Exception as e:
            print(f"Erro ao salvar foto: {str(e)}")
            print(f"Detalhes do erro: Arquivo={photo.filename}, Folder={folder}")
            print(f"Upload folder: {upload_folder}")
            return None
    return None

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# MODELOS
class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    senha_hash = db.Column(db.String(128), nullable=False)
    tipo = db.Column(db.String(20), nullable=False, default='instrutor')  # 'instrutor' ou 'admin'
    
    # Dados pessoais
    cpf = db.Column(db.String(14), unique=True)
    rg = db.Column(db.String(20))
    data_nascimento = db.Column(db.Date)
    telefone = db.Column(db.String(20))
    telefone_emergencia = db.Column(db.String(20))
    
    # Endereço
    cep = db.Column(db.String(9))
    logradouro = db.Column(db.String(100))
    numero = db.Column(db.String(10))
    complemento = db.Column(db.String(100))
    bairro = db.Column(db.String(100))
    cidade = db.Column(db.String(100))
    estado = db.Column(db.String(2))
    
    # Dados profissionais
    formacao = db.Column(db.String(100))
    especializacao = db.Column(db.String(100))
    numero_registro = db.Column(db.String(50))  # Número de registro profissional
    data_admissao = db.Column(db.Date)
    status = db.Column(db.String(20), default='ativo')  # ativo, inativo, afastado, etc
    observacoes = db.Column(db.Text)
    
    # Documentos
    foto = db.Column(db.String(255))  # Caminho para a foto
    comprovante_residencia = db.Column(db.String(255))  # Caminho para o documento
    certificados = db.Column(db.String(255))  # Caminho para certificados
    
    # Relacionamentos
    atividades = db.relationship('Atividade', backref='instrutor', lazy=True)
    turmas = db.relationship('Turma', backref='instrutor', lazy=True)

    def verificar_senha(self, senha):
        return check_password_hash(self.senha_hash, senha)

class Aluno(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    foto = db.Column(db.String(255))  # Caminho para a foto do aluno
    email = db.Column(db.String(100), unique=True)  # Email para login
    senha_hash = db.Column(db.String(128))  # Senha para login
    rg = db.Column(db.String(20), nullable=False)
    cpf = db.Column(db.String(14), unique=True, nullable=False)  # Alterado para unique=True
    data_nascimento = db.Column(db.Date, nullable=False)
    idade = db.Column(db.Integer, nullable=False)
    responsavel = db.Column(db.String(100), nullable=False)
    cpf_responsavel = db.Column(db.String(14), nullable=False)
    contato = db.Column(db.String(100), nullable=False)
    contato_emergencia = db.Column(db.String(100), nullable=False)
    tipo_sanguineo = db.Column(db.String(5))
    alergias = db.Column(db.Text)
    medicamentos = db.Column(db.Text)
    plano_saude = db.Column(db.String(100))
    numero_plano_saude = db.Column(db.String(50))
    
    # Endereço
    cep = db.Column(db.String(9), nullable=False)
    logradouro = db.Column(db.String(100), nullable=False)
    numero = db.Column(db.String(10), nullable=False)
    complemento = db.Column(db.String(100))
    bairro = db.Column(db.String(100), nullable=False)
    cidade = db.Column(db.String(100), nullable=False)
    estado = db.Column(db.String(2), nullable=False)
    
    status = db.Column(db.String(20), default='ativo')  # ativo ou inativo
    observacoes = db.Column(db.Text)  # Adicionado campo observacoes
    participacoes = db.relationship('Participacao', backref='aluno', lazy=True)

    def verificar_senha(self, senha):
        return check_password_hash(self.senha_hash, senha)

    def definir_senha(self, senha):
        self.senha_hash = generate_password_hash(senha)

class Atividade(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(100), nullable=False)
    descricao = db.Column(db.Text, nullable=False)
    data = db.Column(db.DateTime, nullable=False)
    instrutor_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)
    participacoes = db.relationship('Participacao', backref='atividade', lazy=True)

class Participacao(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    aluno_id = db.Column(db.Integer, db.ForeignKey('aluno.id'), nullable=False)
    atividade_id = db.Column(db.Integer, db.ForeignKey('atividade.id'), nullable=False)
    presente = db.Column(db.Boolean, default=False)
    observacao = db.Column(db.Text)

class Curso(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    descricao = db.Column(db.Text, nullable=False)
    carga_horaria = db.Column(db.Integer, nullable=False)
    duracao = db.Column(db.Integer, nullable=False)  # Duração em meses
    requisitos = db.Column(db.Text)
    status = db.Column(db.String(20), default='ativo')  # ativo ou inativo
    observacoes = db.Column(db.Text)
    turmas = db.relationship('Turma', backref='curso', lazy=True)
    disciplinas = db.relationship('Disciplina', backref='curso', lazy=True)
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

class Disciplina(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    descricao = db.Column(db.Text)
    carga_horaria = db.Column(db.Integer, nullable=False)
    curso_id = db.Column(db.Integer, db.ForeignKey('curso.id'), nullable=False)
    instrutor_id = db.Column(db.Integer, db.ForeignKey('usuario.id'))
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

class Turma(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    curso_id = db.Column(db.Integer, db.ForeignKey('curso.id'), nullable=False)
    instrutor_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)
    data_inicio = db.Column(db.Date, nullable=False)
    data_fim = db.Column(db.Date, nullable=False)
    horario_inicio_manha = db.Column(db.String(5), nullable=True)  # Formato: "08:00"
    horario_fim_manha = db.Column(db.String(5), nullable=True)     # Formato: "12:00"
    horario_inicio_tarde = db.Column(db.String(5), nullable=True)  # Formato: "14:00"
    horario_fim_tarde = db.Column(db.String(5), nullable=True)     # Formato: "18:00"
    turno = db.Column(db.String(20), nullable=False, default='manha')  # manha, tarde, integral
    local = db.Column(db.String(200), nullable=False)
    vagas = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), default='ativa')  # ativa, concluída, cancelada
    observacoes = db.Column(db.Text)  # Adicionado campo observacoes
    alunos = db.relationship('Aluno', secondary='aluno_turma', backref=db.backref('turmas', lazy='dynamic'))
    disciplinas = db.relationship('Disciplina', secondary='turma_disciplina', backref=db.backref('turmas', lazy='dynamic'))
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

# Tabela de associação entre Turma e Disciplina
turma_disciplina = db.Table('turma_disciplina',
    db.Column('turma_id', db.Integer, db.ForeignKey('turma.id'), primary_key=True),
    db.Column('disciplina_id', db.Integer, db.ForeignKey('disciplina.id'), primary_key=True),
    db.Column('data_inicio', db.Date),
    db.Column('data_fim', db.Date)
)

class Aula(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    turma_id = db.Column(db.Integer, db.ForeignKey('turma.id'), nullable=False)
    disciplina_id = db.Column(db.Integer, db.ForeignKey('disciplina.id'), nullable=False)
    instrutor_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)
    data = db.Column(db.DateTime, nullable=False)
    conteudo = db.Column(db.Text, nullable=False)
    observacoes = db.Column(db.Text)
    status = db.Column(db.String(20), default='realizada')  # realizada, cancelada, remarcada
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    turma = db.relationship('Turma', backref='aulas')
    disciplina = db.relationship('Disciplina', backref='aulas')
    instrutor = db.relationship('Usuario', backref='aulas_ministradas')
    presencas = db.relationship('Presenca', backref='aula', cascade='all, delete-orphan')

class Presenca(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    aula_id = db.Column(db.Integer, db.ForeignKey('aula.id'), nullable=False)
    aluno_id = db.Column(db.Integer, db.ForeignKey('aluno.id'), nullable=False)
    presente = db.Column(db.Boolean, default=False)
    justificativa = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    aluno = db.relationship('Aluno', backref='presencas')

# Tabela de associação entre Aluno e Turma
aluno_turma = db.Table('aluno_turma',
    db.Column('aluno_id', db.Integer, db.ForeignKey('aluno.id'), primary_key=True),
    db.Column('turma_id', db.Integer, db.ForeignKey('turma.id'), primary_key=True),
    db.Column('data_matricula', db.DateTime, default=datetime.now)
)

# ROTAS
@app.route('/')
def index():
    if 'usuario_id' in session:
        return redirect(url_for('area_instrutor'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        
        # Primeiro verifica se é um usuário administrativo (admin/instrutor)
        usuario = Usuario.query.filter_by(email=email).first()
        if usuario and usuario.verificar_senha(senha):
            session['usuario_id'] = usuario.id
            session['usuario_tipo'] = usuario.tipo
            session['usuario_nome'] = usuario.nome
            return redirect(url_for('area_instrutor'))
            
        # Se não for usuário administrativo, verifica se é um aluno
        aluno = Aluno.query.filter_by(email=email).first()
        if aluno and aluno.verificar_senha(senha):
            if aluno.status == 'inativo':
                flash('Sua conta está inativa. Entre em contato com a administração.')
                return redirect(url_for('login'))
                
            session['aluno_id'] = aluno.id
            session['aluno_nome'] = aluno.nome
            return redirect(url_for('area_aluno'))
            
        flash('Email ou senha inválidos')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if 'usuario_id' in session:
        return redirect(url_for('area_instrutor'))
    elif 'aluno_id' in session:
        return redirect(url_for('area_aluno'))
    return redirect(url_for('index'))

@app.route('/instrutor')
def area_instrutor():
    if 'usuario_id' not in session:
        return redirect(url_for('login'))
        
    usuario = Usuario.query.get(session['usuario_id'])
    
    # Consultas atualizadas para estatísticas
    alunos = Aluno.query.filter_by(status='ativo').all()
    atividades = Atividade.query.order_by(Atividade.data.desc()).all()
    turmas = Turma.query.filter_by(status='ativa').all()
    
    # Estatísticas
    total_alunos = Aluno.query.filter_by(status='ativo').count()
    total_atividades = Atividade.query.count()
    total_turmas = Turma.query.filter_by(status='ativa').count()
    
    # Atividades recentes (últimas 5)
    hoje = datetime.now()
    atividades_recentes = Atividade.query.filter(
        Atividade.data >= hoje
    ).order_by(Atividade.data).limit(5).all()
    
    # Alunos recentes (últimos 5 cadastrados)
    alunos_recentes = Aluno.query.filter_by(
        status='ativo'
    ).order_by(Aluno.id.desc()).limit(5).all()
    
    return render_template('dashboard_instrutor.html',
                         usuario=usuario,
                         alunos=alunos_recentes,
                         atividades=atividades,
                         turmas=turmas,
                         total_alunos=total_alunos,
                         total_atividades=total_atividades,
                         total_turmas=total_turmas,
                         atividades_recentes=atividades_recentes)

@app.route('/aluno')
def area_aluno():
    if 'aluno_id' not in session:
        return redirect(url_for('login'))
        
    aluno = Aluno.query.get(session['aluno_id'])
    
    # Busca as participações do aluno
    participacoes = Participacao.query.filter_by(aluno_id=aluno.id).all()
    
    # Estatísticas
    total_atividades = len(participacoes)
    total_presencas = len([p for p in participacoes if p.presente])
    
    # Próximas atividades (atividades futuras)
    hoje = datetime.now()
    proximas_atividades = Atividade.query.filter(Atividade.data >= hoje).order_by(Atividade.data).limit(5).all()
    
    # Turmas do aluno
    turmas = aluno.turmas.all()
    
    return render_template('dashboard_aluno.html',
                         aluno=aluno,
                         participacoes=participacoes,
                         total_atividades=total_atividades,
                         total_presencas=total_presencas,
                         proximas_atividades=proximas_atividades,
                         turmas=turmas)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario_id' not in session or \
           Usuario.query.get(session['usuario_id']).tipo != 'admin':
            flash('Acesso negado. Apenas administradores podem realizar esta ação.')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario_id' not in session and 'aluno_id' not in session:
            flash('Por favor, faça login para acessar esta página.')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/cadastrar_usuario', methods=['GET', 'POST'])
@admin_required
def cadastrar_usuario():
    if request.method == 'POST':
        if request.form['senha'] != request.form['confirmar_senha']:
            flash('As senhas não coincidem')
            return render_template('cadastrar_usuario.html')
            
        try:
            # Verifica se o email já existe em ambas as tabelas
            if Usuario.query.filter_by(email=request.form['email']).first() or \
               Aluno.query.filter_by(email=request.form['email']).first():
                flash('Este email já está cadastrado')
                return render_template('cadastrar_usuario.html')
            
            tipo = request.form['tipo']
            
            if tipo in ['instrutor', 'admin']:
                usuario = Usuario(
                    nome=request.form['nome'],
                    email=request.form['email'],
                    senha_hash=generate_password_hash(request.form['senha']),
                    tipo=tipo  # Usa o tipo selecionado (instrutor ou admin)
                )
                db.session.add(usuario)
                flash(f'{"Administrador" if tipo == "admin" else "Instrutor"} cadastrado com sucesso!')
            
            elif tipo == 'aluno':
                # Calcula a idade baseado na data de nascimento
                data_nascimento = datetime.strptime(request.form['data_nascimento'], '%Y-%m-%d').date()
                hoje = datetime.now().date()
                idade = hoje.year - data_nascimento.year - ((hoje.month, hoje.day) < (data_nascimento.month, data_nascimento.day))
                
                aluno = Aluno(
                    nome=request.form['nome'],
                    email=request.form['email'],
                    senha_hash=generate_password_hash(request.form['senha']),
                    data_nascimento=data_nascimento,
                    idade=idade,
                    responsavel=request.form['responsavel'],
                    contato=request.form['contato'],
                    # Campos obrigatórios com valores padrão temporários
                    rg='Pendente',
                    cpf='Pendente',
                    cpf_responsavel='Pendente',
                    contato_emergencia=request.form['contato'],
                    cep='Pendente',
                    logradouro='Pendente',
                    numero='Pendente',
                    bairro='Pendente',
                    cidade='Pendente',
                    estado='PI'
                )
                db.session.add(aluno)
                flash('Aluno cadastrado com sucesso! Complete o cadastro na seção de alunos.')
            
            db.session.commit()
            return redirect(url_for('dashboard'))
            
        except Exception as e:
            flash('Erro ao cadastrar usuário')
            print(e)
            
    return render_template('cadastrar_usuario.html')

@app.route('/cadastrar_instrutor', methods=['GET', 'POST'])
@admin_required
def cadastrar_instrutor():
    if request.method == 'POST':
        try:
            # Verifica se o email já existe
            if Usuario.query.filter_by(email=request.form['email']).first():
                flash('Este email já está cadastrado')
                return render_template('cadastrar_instrutor.html')

            # Processa a foto se foi enviada
            foto_path = None
            if 'foto' in request.files:
                foto = request.files['foto']
                if foto.filename != '':
                    foto_path = save_photo(foto, 'instrutores')

            # Processa os documentos
            comprovante_path = None
            if 'comprovante_residencia' in request.files:
                comprovante = request.files['comprovante_residencia']
                if comprovante.filename != '':
                    comprovante_path = save_photo(comprovante, 'documentos')

            certificados_path = None
            if 'certificados' in request.files:
                certificados = request.files['certificados']
                if certificados.filename != '':
                    certificados_path = save_photo(certificados, 'certificados')

            instrutor = Usuario(
                nome=request.form['nome'],
                email=request.form['email'],
                senha_hash=generate_password_hash(request.form['senha']),
                tipo='instrutor',
                cpf=request.form['cpf'],
                rg=request.form['rg'],
                data_nascimento=datetime.strptime(request.form['data_nascimento'], '%Y-%m-%d').date(),
                telefone=request.form['telefone'],
                telefone_emergencia=request.form['telefone_emergencia'],
                cep=request.form['cep'],
                logradouro=request.form['logradouro'],
                numero=request.form['numero'],
                complemento=request.form['complemento'],
                bairro=request.form['bairro'],
                cidade=request.form['cidade'],
                estado=request.form['estado'],
                formacao=request.form['formacao'],
                especializacao=request.form['especializacao'],
                numero_registro=request.form['numero_registro'],
                data_admissao=datetime.strptime(request.form['data_admissao'], '%Y-%m-%d').date(),
                status=request.form['status'],
                observacoes=request.form['observacoes'],
                foto=foto_path,
                comprovante_residencia=comprovante_path,
                certificados=certificados_path
            )
            
            db.session.add(instrutor)
            db.session.commit()
            flash('Instrutor cadastrado com sucesso!')
            return redirect(url_for('listar_usuarios'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao cadastrar instrutor: {str(e)}')
            print(f"Erro detalhado: {str(e)}")
            return render_template('cadastrar_instrutor.html')
            
    return render_template('cadastrar_instrutor.html')

@app.route('/cadastrar_aluno', methods=['GET', 'POST'])
@admin_required
def cadastrar_aluno():
    if request.method == 'POST':
        try:
            # Verifica se o CPF já existe
            cpf = request.form['cpf']
            cpf = cpf.replace('.', '').replace('-', '')  # Remove formatação do CPF
            if Aluno.query.filter_by(cpf=cpf).first():
                flash('Este CPF já está cadastrado no sistema')
                return render_template('cadastrar_aluno.html')

            # Verifica se o email já existe
            email = request.form['email']
            if Usuario.query.filter_by(email=email).first() or Aluno.query.filter_by(email=email).first():
                flash('Este email já está cadastrado no sistema')
                return render_template('cadastrar_aluno.html')

            # Processa a foto se foi enviada
            foto_path = None
            if 'foto' in request.files:
                foto = request.files['foto']
                if foto.filename != '':
                    foto_path = save_photo(foto, 'alunos')

            # Processa a data de nascimento e calcula a idade
            data_nascimento = datetime.strptime(request.form['data_nascimento'], '%Y-%m-%d').date()
            hoje = datetime.now().date()
            idade = hoje.year - data_nascimento.year - ((hoje.month, hoje.day) < (data_nascimento.month, data_nascimento.day))

            # Processa o CPF do responsável
            cpf_responsavel = request.form['cpf_responsavel']
            cpf_responsavel = cpf_responsavel.replace('.', '').replace('-', '')

            aluno = Aluno(
                nome=request.form['nome'],
                foto=foto_path,
                email=email,
                senha_hash=generate_password_hash(request.form['senha']),
                rg=request.form['rg'],
                cpf=cpf,  # CPF já limpo
                data_nascimento=data_nascimento,
                idade=idade,  # Idade calculada
                responsavel=request.form['responsavel'],
                cpf_responsavel=cpf_responsavel,  # CPF do responsável limpo
                contato=request.form['contato'],
                contato_emergencia=request.form['contato_emergencia'],
                tipo_sanguineo=request.form['tipo_sanguineo'],
                alergias=request.form['alergias'],
                medicamentos=request.form['medicamentos'],
                plano_saude=request.form['plano_saude'],
                numero_plano_saude=request.form['numero_plano_saude'],
                cep=request.form['cep'],
                logradouro=request.form['logradouro'],
                numero=request.form['numero'],
                complemento=request.form['complemento'],
                bairro=request.form['bairro'],
                cidade=request.form['cidade'],
                estado=request.form['estado'].upper(),  # Converte para maiúsculo
                status='ativo'
            )
            db.session.add(aluno)
            db.session.commit()
            flash('Aluno cadastrado com sucesso!')
            return redirect(url_for('dashboard'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao cadastrar aluno: {str(e)}')
            print(f"Erro detalhado: {str(e)}")
            return render_template('cadastrar_aluno.html')
    return render_template('cadastrar_aluno.html')

@app.route('/aluno/<int:aluno_id>')
def detalhes_aluno(aluno_id):
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
        
    aluno = Aluno.query.get_or_404(aluno_id)
    participacoes = Participacao.query.filter_by(aluno_id=aluno_id).all()
    return render_template('detalhes_aluno.html', aluno=aluno, participacoes=participacoes)

@app.route('/aluno/<int:aluno_id>/atualizar', methods=['POST'])
@admin_required
def atualizar_aluno(aluno_id):
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
        
    aluno = Aluno.query.get_or_404(aluno_id)
    try:
        # Verifica se o CPF já existe e não pertence ao aluno atual
        cpf = request.form['cpf']
        aluno_existente = Aluno.query.filter_by(cpf=cpf).first()
        if aluno_existente and aluno_existente.id != aluno_id:
            flash('Este CPF já está cadastrado no sistema')
            return redirect(url_for('detalhes_aluno', aluno_id=aluno_id))

        # Processa a foto se foi enviada
        if 'foto' in request.files:
            foto = request.files['foto']
            if foto.filename != '':
                # Remove a foto antiga se existir
                if aluno.foto:
                    try:
                        old_photo_path = os.path.join('static', aluno.foto)
                        if os.path.exists(old_photo_path):
                            os.remove(old_photo_path)
                    except Exception as e:
                        print(f"Erro ao remover foto antiga: {str(e)}")
                
                # Salva a nova foto
                foto_path = save_photo(foto, 'alunos')
                aluno.foto = foto_path

        aluno.nome = request.form['nome']
        aluno.email = request.form['email']
        aluno.senha_hash = generate_password_hash(request.form['senha'])
        aluno.rg = request.form['rg']
        aluno.cpf = request.form['cpf']
        aluno.data_nascimento = datetime.strptime(request.form['data_nascimento'], '%Y-%m-%d').date()
        aluno.idade = int(request.form['idade'])
        aluno.responsavel = request.form['responsavel']
        aluno.cpf_responsavel = request.form['cpf_responsavel']
        aluno.contato = request.form['contato']
        aluno.contato_emergencia = request.form['contato_emergencia']
        aluno.tipo_sanguineo = request.form['tipo_sanguineo']
        aluno.alergias = request.form['alergias']
        aluno.medicamentos = request.form['medicamentos']
        aluno.plano_saude = request.form['plano_saude']
        aluno.numero_plano_saude = request.form['numero_plano_saude']
        aluno.cep = request.form['cep']
        aluno.logradouro = request.form['logradouro']
        aluno.numero = request.form['numero']
        aluno.complemento = request.form['complemento']
        aluno.bairro = request.form['bairro']
        aluno.cidade = request.form['cidade']
        aluno.estado = request.form['estado']
        aluno.status = request.form['status']
        
        db.session.commit()
        flash('Aluno atualizado com sucesso!')
    except Exception as e:
        flash('Erro ao atualizar aluno')
        print(e)
    return redirect(url_for('detalhes_aluno', aluno_id=aluno_id))

@app.route('/aluno/<int:aluno_id>/excluir', methods=['POST'])
@admin_required
def excluir_aluno(aluno_id):
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
        
    aluno = Aluno.query.get_or_404(aluno_id)
    try:
        aluno.status = 'inativo'
        db.session.commit()
        flash('Aluno inativado com sucesso!')
    except Exception as e:
        flash('Erro ao inativar aluno')
        print(e)
    return redirect(url_for('dashboard'))

@app.route('/atividade/<int:atividade_id>')
def detalhes_atividade(atividade_id):
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
        
    atividade = Atividade.query.get_or_404(atividade_id)
    alunos = Aluno.query.filter_by(status='ativo').all()
    presencas = {p.aluno_id for p in Participacao.query.filter_by(atividade_id=atividade_id, presente=True)}
    observacoes = {p.aluno_id: p.observacao for p in Participacao.query.filter_by(atividade_id=atividade_id)}
    return render_template('detalhes_atividade.html', 
                         atividade=atividade, 
                         alunos=alunos, 
                         presencas=presencas,
                         observacoes=observacoes)

@app.route('/atividade/<int:atividade_id>/atualizar', methods=['POST'])
@admin_required
def atualizar_atividade(atividade_id):
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
        
    atividade = Atividade.query.get_or_404(atividade_id)
    try:
        atividade.titulo = request.form['titulo']
        atividade.descricao = request.form['descricao']
        atividade.data = datetime.strptime(request.form['data'], '%Y-%m-%d')
        db.session.commit()
        flash('Atividade atualizada com sucesso!')
    except Exception as e:
        flash('Erro ao atualizar atividade')
        print(e)
    return redirect(url_for('detalhes_atividade', atividade_id=atividade_id))

@app.route('/atividade/<int:atividade_id>/excluir', methods=['POST'])
@admin_required
def excluir_atividade(atividade_id):
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
        
    atividade = Atividade.query.get_or_404(atividade_id)
    try:
        db.session.delete(atividade)
        db.session.commit()
        flash('Atividade excluída com sucesso!')
    except Exception as e:
        flash('Erro ao excluir atividade')
        print(e)
    return redirect(url_for('dashboard'))

@app.route('/atividade/<int:atividade_id>/presenca', methods=['POST'])
@admin_required
def registrar_presenca(atividade_id):
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
        
    try:
        # Limpa presenças anteriores
        Participacao.query.filter_by(atividade_id=atividade_id).delete()
        
        # Registra novas presenças
        alunos = Aluno.query.filter_by(status='ativo').all()
        for aluno in alunos:
            presente = f'presenca_{aluno.id}' in request.form
            observacao = request.form.get(f'obs_{aluno.id}', '')
            participacao = Participacao(
                aluno_id=aluno.id,
                atividade_id=atividade_id,
                presente=presente,
                observacao=observacao
            )
            db.session.add(participacao)
        
        db.session.commit()
        flash('Presenças registradas com sucesso!')
    except Exception as e:
        flash('Erro ao registrar presenças')
        print(e)
    return redirect(url_for('detalhes_atividade', atividade_id=atividade_id))

@app.route('/resetar_senha', methods=['GET', 'POST'])
def resetar_senha():
    if request.method == 'POST':
        email = request.form['email']
        usuario = Usuario.query.filter_by(email=email).first()
        
        if usuario:
            # Aqui você implementaria o envio real do email
            # Por enquanto, apenas simulamos com uma mensagem
            flash('Se o email existir em nossa base, você receberá as instruções para resetar sua senha.')
        else:
            # Mesmo que o usuário não exista, mostramos a mesma mensagem por segurança
            flash('Se o email existir em nossa base, você receberá as instruções para resetar sua senha.')
        
        return redirect(url_for('login'))
    return render_template('resetar_senha.html')

@app.route('/nova_atividade', methods=['POST'])
@admin_required
def nova_atividade():
    if request.method == 'POST':
        try:
            # Converte a data para datetime com horário inicial do dia
            data_str = request.form['data']
            data = datetime.strptime(data_str, '%Y-%m-%d')
            data = data.replace(hour=8, minute=0)  # Define horário padrão como 8:00

            atividade = Atividade(
                titulo=request.form['titulo'],
                descricao=request.form['descricao'],
                data=data,
                instrutor_id=session['usuario_id']
            )
            db.session.add(atividade)
            db.session.commit()
            flash('Atividade criada com sucesso!')
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao criar atividade: {str(e)}')
            print(f"Erro detalhado: {str(e)}")
        return redirect(url_for('dashboard'))

def criar_usuario_inicial():
    with app.app_context():
        if not Usuario.query.filter_by(email='admin@bombeiromirim.com').first():
            admin = Usuario(
                nome='Administrador',
                email='admin@bombeiromirim.com',
                senha_hash=generate_password_hash('admin123'),
                tipo='admin'
            )
            db.session.add(admin)
            db.session.commit()

@app.route('/cursos')
def listar_cursos():
    if 'usuario_id' not in session:
        return redirect(url_for('login'))
    cursos = Curso.query.all()
    return render_template('cursos.html', cursos=cursos)

@app.route('/cursos/novo', methods=['GET', 'POST'])
@login_required
def novo_curso():
    form = CursoForm()
    if form.validate_on_submit():
        try:
            curso = Curso(
                nome=form.nome.data,
                descricao=form.descricao.data,
                carga_horaria=form.carga_horaria.data,
                duracao=form.duracao.data,
                requisitos=form.requisitos.data,
                status=form.status.data,
                observacoes=form.observacoes.data
            )
            db.session.add(curso)
            db.session.commit()
            flash('Curso cadastrado com sucesso!', 'success')
            return redirect(url_for('listar_cursos'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao cadastrar curso: {str(e)}', 'error')
    
    return render_template('novo_curso.html', form=form)

@app.route('/curso/<int:curso_id>')
def detalhes_curso(curso_id):
    if 'usuario_id' not in session:
        return redirect(url_for('login'))
    curso = Curso.query.get_or_404(curso_id)
    return render_template('detalhes_curso.html', curso=curso)

@app.route('/curso/<int:curso_id>/atualizar', methods=['POST'])
@login_required
def atualizar_curso(curso_id):
    curso = Curso.query.get_or_404(curso_id)
    try:
        curso.nome = request.form['nome']
        curso.descricao = request.form['descricao']
        curso.carga_horaria = int(request.form['carga_horaria'])
        curso.duracao = int(request.form['duracao'])
        curso.requisitos = request.form.get('requisitos', '')
        curso.status = request.form['status']
        curso.observacoes = request.form.get('observacoes', '')
        db.session.commit()
        flash('Curso atualizado com sucesso!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao atualizar curso: {str(e)}', 'error')
    return redirect(url_for('detalhes_curso', curso_id=curso_id))

@app.route('/turmas')
def listar_turmas():
    if 'usuario_id' not in session:
        return redirect(url_for('login'))
    
    # Busca todas as turmas com seus relacionamentos
    turmas = Turma.query.options(
        db.joinedload(Turma.curso),
        db.joinedload(Turma.instrutor),
        db.joinedload(Turma.disciplinas)
    ).all()
    
    return render_template('turmas.html', turmas=turmas)

@app.route('/turmas/nova', methods=['GET', 'POST'])
@login_required
def nova_turma():
    form = TurmaForm()
    form.curso_id.choices = [(c.id, c.nome) for c in Curso.query.filter_by(status='ativo').all()]
    form.instrutor_id.choices = [(i.id, i.nome) for i in Usuario.query.filter_by(tipo='instrutor', status='ativo').all()]
    
    if form.validate_on_submit():
        try:
            turma = Turma(
                nome=form.nome.data,
                curso_id=form.curso_id.data,
                instrutor_id=form.instrutor_id.data,
                data_inicio=form.data_inicio.data,
                data_fim=form.data_fim.data,
                turno=form.turno.data,
                horario_inicio_manha=form.horario_inicio_manha.data,
                horario_fim_manha=form.horario_fim_manha.data,
                horario_inicio_tarde=form.horario_inicio_tarde.data,
                horario_fim_tarde=form.horario_fim_tarde.data,
                local=form.local.data,
                vagas=form.vagas.data,
                status=form.status.data,
                observacoes=form.observacoes.data
            )
            
            # Adiciona as disciplinas do curso à turma
            curso = Curso.query.get(form.curso_id.data)
            if curso and curso.disciplinas:
                turma.disciplinas.extend(curso.disciplinas)
            
            db.session.add(turma)
            db.session.commit()
            flash('Turma cadastrada com sucesso!', 'success')
            return redirect(url_for('listar_turmas'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao cadastrar turma: {str(e)}', 'error')
            print(f"Erro detalhado ao criar turma: {str(e)}")
    
    return render_template('nova_turma.html', form=form)

@app.route('/turma/<int:turma_id>')
def detalhes_turma(turma_id):
    if 'usuario_id' not in session:
        return redirect(url_for('login'))
    turma = Turma.query.get_or_404(turma_id)
    instrutores = Usuario.query.filter_by(tipo='instrutor', status='ativo').all()
    return render_template('detalhes_turma.html', turma=turma, instrutores=instrutores)

@app.route('/turma/<int:turma_id>/atualizar', methods=['POST'])
@admin_required
def atualizar_turma(turma_id):
    turma = Turma.query.get_or_404(turma_id)
    try:
        turma.nome = request.form['nome']
        turma.instrutor_id = int(request.form['instrutor_id'])
        turma.data_inicio = datetime.strptime(request.form['data_inicio'], '%Y-%m-%d').date()
        turma.data_fim = datetime.strptime(request.form['data_fim'], '%Y-%m-%d').date()
        turma.status = request.form['status']
        
        db.session.commit()
        flash('Turma atualizada com sucesso!')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao atualizar turma: {str(e)}')
        print(f"Erro detalhado: {str(e)}")
    return redirect(url_for('detalhes_turma', turma_id=turma.id))

@app.route('/aluno/resetar_senha', methods=['GET', 'POST'])
def resetar_senha_aluno():
    if request.method == 'POST':
        email = request.form['email']
        aluno = Aluno.query.filter_by(email=email).first()
        
        if aluno:
            # Aqui você implementaria o envio real do email
            # Por enquanto, apenas simulamos com uma mensagem
            flash('Se o email existir em nossa base, você receberá as instruções para resetar sua senha.')
        else:
            # Mesmo que o aluno não exista, mostramos a mesma mensagem por segurança
            flash('Se o email existir em nossa base, você receberá as instruções para resetar sua senha.')
        
        return redirect(url_for('login'))
    return render_template('resetar_senha_aluno.html')

@app.route('/aluno/perfil')
def perfil_aluno():
    if 'aluno_id' not in session:
        return redirect(url_for('login'))
        
    aluno = Aluno.query.get_or_404(session['aluno_id'])
    participacoes = Participacao.query.filter_by(aluno_id=aluno.id).all()
    return render_template('perfil_aluno.html', aluno=aluno, participacoes=participacoes)

@app.route('/usuarios')
@admin_required
def listar_usuarios():
    # Busca todos os usuários (instrutores e admin)
    usuarios = Usuario.query.all()
    
    # Busca todos os alunos ativos
    alunos = Aluno.query.filter_by(status='ativo').all()
    
    return render_template('usuarios.html', 
                         usuarios=usuarios, 
                         alunos=alunos)

@app.route('/usuario/<int:usuario_id>/alterar_senha', methods=['POST'])
@admin_required
def alterar_senha_usuario(usuario_id):
    usuario = Usuario.query.get_or_404(usuario_id)
    try:
        nova_senha = request.form['nova_senha']
        if len(nova_senha) < 6:
            flash('A senha deve ter no mínimo 6 caracteres')
            return redirect(url_for('listar_usuarios'))
            
        usuario.senha_hash = generate_password_hash(nova_senha)
        db.session.commit()
        flash('Senha alterada com sucesso!')
    except Exception as e:
        flash('Erro ao alterar senha')
        print(e)
    return redirect(url_for('listar_usuarios'))

@app.route('/aluno/<int:aluno_id>/alterar_senha', methods=['POST'])
@admin_required
def alterar_senha_aluno(aluno_id):
    aluno = Aluno.query.get_or_404(aluno_id)
    try:
        nova_senha = request.form['nova_senha']
        if len(nova_senha) < 6:
            flash('A senha deve ter no mínimo 6 caracteres')
            return redirect(url_for('listar_usuarios'))
            
        aluno.senha_hash = generate_password_hash(nova_senha)
        db.session.commit()
        flash('Senha alterada com sucesso!')
    except Exception as e:
        flash('Erro ao alterar senha')
        print(e)
    return redirect(url_for('listar_usuarios'))

@app.route('/instrutores')
@admin_required
def listar_instrutores():
    instrutores = Usuario.query.filter_by(tipo='instrutor').all()
    return render_template('instrutores.html', instrutores=instrutores)

@app.route('/instrutor/<int:instrutor_id>/atualizar', methods=['POST'])
@admin_required
def atualizar_instrutor(instrutor_id):
    instrutor = Usuario.query.get_or_404(instrutor_id)
    if instrutor.tipo != 'instrutor':
        flash('Usuário não é um instrutor')
        return redirect(url_for('listar_instrutores'))
        
    try:
        # Atualiza os dados básicos
        instrutor.nome = request.form['nome']
        instrutor.email = request.form['email']
        
        # Se uma nova senha foi fornecida
        if request.form.get('senha'):
            instrutor.senha_hash = generate_password_hash(request.form['senha'])
            
        # Atualiza a foto se foi enviada
        if 'foto' in request.files:
            foto = request.files['foto']
            if foto.filename != '':
                # Remove a foto antiga se existir
                if instrutor.foto:
                    try:
                        old_photo_path = os.path.join(app.root_path, 'static', instrutor.foto)
                        if os.path.exists(old_photo_path):
                            os.remove(old_photo_path)
                    except Exception as e:
                        print(f"Erro ao remover foto antiga: {str(e)}")
                
                # Salva a nova foto
                foto_path = save_photo(foto, 'instrutores')
                instrutor.foto = foto_path
        
        db.session.commit()
        flash('Instrutor atualizado com sucesso!')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao atualizar instrutor: {str(e)}')
        print(f"Erro detalhado: {str(e)}")
    
    return redirect(url_for('listar_instrutores'))

@app.route('/alunos')
@admin_required
def listar_alunos():
    status = request.args.get('status', 'todos')
    
    if status == 'ativo':
        alunos = Aluno.query.filter_by(status='ativo').all()
    elif status == 'inativo':
        alunos = Aluno.query.filter_by(status='inativo').all()
    else:
        alunos = Aluno.query.all()
        
    return render_template('alunos.html', alunos=alunos, status_filtro=status)

@app.route('/curso/<int:curso_id>/disciplinas')
@admin_required
def listar_disciplinas(curso_id):
    curso = Curso.query.get_or_404(curso_id)
    instrutores = Usuario.query.filter_by(tipo='instrutor', status='ativo').all()
    return render_template('disciplinas.html', curso=curso, instrutores=instrutores)

@app.route('/curso/<int:curso_id>/disciplina/nova', methods=['POST'])
@admin_required
def nova_disciplina(curso_id):
    curso = Curso.query.get_or_404(curso_id)
    try:
        disciplina = Disciplina(
            nome=request.form['nome'],
            descricao=request.form['descricao'],
            carga_horaria=int(request.form['carga_horaria']),
            curso_id=curso_id,
            instrutor_id=request.form.get('instrutor_id')
        )
        db.session.add(disciplina)
        db.session.commit()
        flash('Disciplina adicionada com sucesso!')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao adicionar disciplina: {str(e)}')
        print(f"Erro detalhado: {str(e)}")
    return redirect(url_for('listar_disciplinas', curso_id=curso_id))

@app.route('/disciplina/<int:disciplina_id>/atualizar', methods=['POST'])
@admin_required
def atualizar_disciplina(disciplina_id):
    disciplina = Disciplina.query.get_or_404(disciplina_id)
    try:
        disciplina.nome = request.form['nome']
        disciplina.descricao = request.form['descricao']
        disciplina.carga_horaria = int(request.form['carga_horaria'])
        disciplina.instrutor_id = request.form.get('instrutor_id')
        
        db.session.commit()
        flash('Disciplina atualizada com sucesso!')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao atualizar disciplina: {str(e)}')
        print(f"Erro detalhado: {str(e)}")
    return redirect(url_for('listar_disciplinas', curso_id=disciplina.curso_id))

@app.route('/disciplina/<int:disciplina_id>/excluir', methods=['POST'])
@admin_required
def excluir_disciplina(disciplina_id):
    disciplina = Disciplina.query.get_or_404(disciplina_id)
    curso_id = disciplina.curso_id
    try:
        db.session.delete(disciplina)
        db.session.commit()
        flash('Disciplina excluída com sucesso!')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao excluir disciplina: {str(e)}')
        print(f"Erro detalhado: {str(e)}")
    return redirect(url_for('listar_disciplinas', curso_id=curso_id))

@app.route('/turma/<int:turma_id>/disciplinas')
@admin_required
def gerenciar_disciplinas_turma(turma_id):
    turma = Turma.query.get_or_404(turma_id)
    instrutores = Usuario.query.filter_by(tipo='instrutor', status='ativo').all()
    return render_template('gerenciar_disciplinas_turma.html', turma=turma, instrutores=instrutores)

@app.route('/turma/<int:turma_id>/disciplinas/adicionar', methods=['POST'])
@admin_required
def adicionar_disciplina_turma(turma_id):
    turma = Turma.query.get_or_404(turma_id)
    try:
        disciplina = Disciplina(
            nome=request.form['nome'],
            descricao=request.form['descricao'],
            carga_horaria=int(request.form['carga_horaria']),
            instrutor_id=request.form['instrutor_id'] or None,
            status=request.form['status'],
            turma_id=turma.id
        )
        db.session.add(disciplina)
        db.session.commit()
        flash('Disciplina adicionada com sucesso!')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao adicionar disciplina: {str(e)}')
        print(f"Erro detalhado: {str(e)}")
    return redirect(url_for('gerenciar_disciplinas_turma', turma_id=turma.id))

@app.route('/turma/<int:turma_id>/disciplinas/<int:disciplina_id>/atualizar', methods=['POST'])
@admin_required
def atualizar_disciplina_turma(turma_id, disciplina_id):
    turma = Turma.query.get_or_404(turma_id)
    disciplina = Disciplina.query.get_or_404(disciplina_id)
    
    if disciplina.turma_id != turma.id:
        flash('Disciplina não pertence a esta turma!')
        return redirect(url_for('gerenciar_disciplinas_turma', turma_id=turma.id))
    
    try:
        disciplina.nome = request.form['nome']
        disciplina.descricao = request.form['descricao']
        disciplina.carga_horaria = int(request.form['carga_horaria'])
        disciplina.instrutor_id = request.form['instrutor_id'] or None
        disciplina.status = request.form['status']
        
        db.session.commit()
        flash('Disciplina atualizada com sucesso!')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao atualizar disciplina: {str(e)}')
        print(f"Erro detalhado: {str(e)}")
    return redirect(url_for('gerenciar_disciplinas_turma', turma_id=turma.id))

@app.route('/turma/<int:turma_id>/disciplinas/<int:disciplina_id>/remover', methods=['POST'])
@admin_required
def remover_disciplina_turma(turma_id, disciplina_id):
    turma = Turma.query.get_or_404(turma_id)
    disciplina = Disciplina.query.get_or_404(disciplina_id)
    
    if disciplina.turma_id != turma.id:
        flash('Disciplina não pertence a esta turma!')
        return redirect(url_for('gerenciar_disciplinas_turma', turma_id=turma.id))
    
    try:
        db.session.delete(disciplina)
        db.session.commit()
        flash('Disciplina removida com sucesso!')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao remover disciplina: {str(e)}')
        print(f"Erro detalhado: {str(e)}")
    return redirect(url_for('gerenciar_disciplinas_turma', turma_id=turma.id))

@app.route('/turma/<int:turma_id>/alunos', methods=['GET', 'POST'])
@admin_required
def gerenciar_alunos_turma(turma_id):
    turma = Turma.query.get_or_404(turma_id)
    
    if request.method == 'POST':
        try:
            # Limpa os alunos existentes
            turma.alunos = []
            
            # Adiciona os alunos selecionados
            alunos_ids = request.form.getlist('alunos')
            for aluno_id in alunos_ids:
                aluno = Aluno.query.get(int(aluno_id))
                if aluno and aluno.status == 'ativo':
                    turma.alunos.append(aluno)
            
            db.session.commit()
            flash('Alunos da turma atualizados com sucesso!')
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao atualizar alunos: {str(e)}')
            
    return render_template('alunos_turma.html', 
                         turma=turma,
                         todos_alunos=Aluno.query.filter_by(status='ativo').all())

@app.route('/turma/<int:turma_id>/aulas')
def listar_aulas(turma_id):
    turma = Turma.query.get_or_404(turma_id)
    return render_template('aulas.html', turma=turma)

@app.route('/aula/<int:aula_id>')
def detalhes_aula(aula_id):
    aula = Aula.query.get_or_404(aula_id)
    return render_template('detalhes_aula.html', aula=aula)

@app.route('/aula/<int:aula_id>/presenca', methods=['POST'])
def registrar_presenca_aula(aula_id):
    aula = Aula.query.get_or_404(aula_id)
    
    if request.method == 'POST':
        try:
            for aluno in aula.turma.alunos:
                presenca = Presenca.query.filter_by(aula_id=aula.id, aluno_id=aluno.id).first()
                if not presenca:
                    presenca = Presenca(aula_id=aula.id, aluno_id=aluno.id)
                    db.session.add(presenca)
                
                presenca.presente = f'presenca_{aluno.id}' in request.form
                presenca.justificativa = request.form.get(f'justificativa_{aluno.id}', '')
            
            db.session.commit()
            flash('Presenças registradas com sucesso!')
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao registrar presenças: {str(e)}')
    
    return redirect(url_for('detalhes_aula', aula_id=aula.id))

@app.route('/aula/<int:aula_id>/atualizar', methods=['POST'])
def atualizar_aula(aula_id):
    aula = Aula.query.get_or_404(aula_id)
    
    if request.method == 'POST':
        try:
            aula.disciplina_id = request.form['disciplina_id']
            aula.instrutor_id = request.form['instrutor_id']
            aula.data = datetime.strptime(f"{request.form['data']} {request.form['hora']}", '%Y-%m-%d %H:%M')
            aula.conteudo = request.form['conteudo']
            aula.observacoes = request.form['observacoes']
            aula.status = request.form['status']
            
            db.session.commit()
            flash('Aula atualizada com sucesso!')
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao atualizar aula: {str(e)}')
            print(f"Erro detalhado: {str(e)}")
    
    return redirect(url_for('detalhes_aula', aula_id=aula.id))

@app.route('/turma/<int:turma_id>/aulas/nova', methods=['POST'])
@login_required
def nova_aula(turma_id):
    turma = Turma.query.get_or_404(turma_id)
    try:
        aula = Aula(
            turma_id=turma_id,
            disciplina_id=request.form['disciplina_id'],
            instrutor_id=request.form['instrutor_id'],
            data=datetime.strptime(f"{request.form['data']} {request.form['hora']}", '%Y-%m-%d %H:%M'),
            conteudo=request.form['conteudo'],
            observacoes=request.form.get('observacoes', ''),
            status='realizada'
        )
        db.session.add(aula)
        db.session.commit()
        flash('Aula cadastrada com sucesso!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao cadastrar aula: {str(e)}', 'error')
    return redirect(url_for('listar_aulas', turma_id=turma_id))

class AlunoForm(FlaskForm):
    nome_completo = StringField('Nome Completo', validators=[DataRequired(), Length(min=3, max=100)])
    data_nascimento = DateField('Data de Nascimento', validators=[DataRequired()])
    sexo = SelectField('Sexo', choices=[('M', 'Masculino'), ('F', 'Feminino')], validators=[DataRequired()])
    rg = StringField('RG', validators=[DataRequired(), Length(max=20)])
    cpf = StringField('CPF', validators=[DataRequired(), Length(max=14)])
    endereco = StringField('Endereço', validators=[DataRequired(), Length(max=200)])
    telefone = StringField('Telefone', validators=[DataRequired(), Length(max=20)])
    email = EmailField('Email', validators=[Optional(), Email(), Length(max=100)])
    nome_responsavel = StringField('Nome do Responsável', validators=[DataRequired(), Length(max=100)])
    telefone_responsavel = StringField('Telefone do Responsável', validators=[DataRequired(), Length(max=20)])
    email_responsavel = EmailField('Email do Responsável', validators=[Optional(), Email(), Length(max=100)])
    status = SelectField('Status', choices=[('ativo', 'Ativo'), ('inativo', 'Inativo')], validators=[DataRequired()])
    observacoes = TextAreaField('Observações', validators=[Optional(), Length(max=500)])
    foto = FileField('Foto')

class CursoForm(FlaskForm):
    nome = StringField('Nome do Curso', validators=[DataRequired(), Length(min=3, max=100)])
    descricao = TextAreaField('Descrição', validators=[DataRequired(), Length(max=500)])
    carga_horaria = IntegerField('Carga Horária', validators=[DataRequired(), NumberRange(min=1)])
    duracao = IntegerField('Duração (meses)', validators=[DataRequired(), NumberRange(min=1)])
    requisitos = TextAreaField('Requisitos', validators=[Optional(), Length(max=500)])
    status = SelectField('Status', choices=[('ativo', 'Ativo'), ('inativo', 'Inativo')], validators=[DataRequired()])
    observacoes = TextAreaField('Observações', validators=[Optional(), Length(max=500)])

class TurmaForm(FlaskForm):
    nome = StringField('Nome da Turma', validators=[DataRequired(), Length(min=3, max=100)])
    curso_id = SelectField('Curso', coerce=int, validators=[DataRequired()])
    instrutor_id = SelectField('Instrutor', coerce=int, validators=[DataRequired()])
    data_inicio = DateField('Data de Início', validators=[DataRequired()])
    data_fim = DateField('Data de Término', validators=[DataRequired()])
    turno = SelectField('Turno', choices=[
        ('manha', 'Manhã'),
        ('tarde', 'Tarde'),
        ('integral', 'Integral')
    ], validators=[DataRequired()])
    horario_inicio_manha = StringField('Horário Início Manhã', validators=[Optional(), Length(max=5)])
    horario_fim_manha = StringField('Horário Fim Manhã', validators=[Optional(), Length(max=5)])
    horario_inicio_tarde = StringField('Horário Início Tarde', validators=[Optional(), Length(max=5)])
    horario_fim_tarde = StringField('Horário Fim Tarde', validators=[Optional(), Length(max=5)])
    local = StringField('Local', validators=[DataRequired(), Length(max=200)])
    vagas = IntegerField('Vagas', validators=[DataRequired(), NumberRange(min=1)])
    status = SelectField('Status', choices=[
        ('ativa', 'Ativa'),
        ('concluida', 'Concluída'),
        ('cancelada', 'Cancelada')
    ], validators=[DataRequired()])
    observacoes = TextAreaField('Observações', validators=[Optional(), Length(max=500)])

    def validate(self, extra_validators=None):
        if not super().validate(extra_validators=extra_validators):
            return False
        # Validação dos horários baseada no turno
        if self.turno.data == 'manha':
            if not self.horario_inicio_manha.data or not self.horario_fim_manha.data:
                self.horario_inicio_manha.errors.append('Horários da manhã são obrigatórios para turno da manhã')
                return False
            self.horario_inicio_tarde.data = None
            self.horario_fim_tarde.data = None
        elif self.turno.data == 'tarde':
            if not self.horario_inicio_tarde.data or not self.horario_fim_tarde.data:
                self.horario_inicio_tarde.errors.append('Horários da tarde são obrigatórios para turno da tarde')
                return False
            self.horario_inicio_manha.data = None
            self.horario_fim_manha.data = None
        elif self.turno.data == 'integral':
            if not all([self.horario_inicio_manha.data, self.horario_fim_manha.data,
                        self.horario_inicio_tarde.data, self.horario_fim_tarde.data]):
                self.horario_inicio_manha.errors.append('Todos os horários são obrigatórios para turno integral')
                return False
        return True

@app.route('/alunos/novo', methods=['GET', 'POST'])
@login_required
def novo_aluno():
    form = AlunoForm()
    if form.validate_on_submit():
        try:
            aluno = Aluno(
                nome_completo=form.nome_completo.data,
                data_nascimento=form.data_nascimento.data,
                sexo=form.sexo.data,
                rg=form.rg.data,
                cpf=form.cpf.data,
                endereco=form.endereco.data,
                telefone=form.telefone.data,
                email=form.email.data,
                nome_responsavel=form.nome_responsavel.data,
                telefone_responsavel=form.telefone_responsavel.data,
                email_responsavel=form.email_responsavel.data,
                status=form.status.data,
                observacoes=form.observacoes.data
            )
            
            if form.foto.data:
                filename = secure_filename(form.foto.data.filename)
                form.foto.data.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                aluno.foto = filename
            
            db.session.add(aluno)
            db.session.commit()
            flash('Aluno cadastrado com sucesso!', 'success')
            return redirect(url_for('listar_alunos'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao cadastrar aluno: {str(e)}', 'error')
    
    return render_template('novo_aluno.html', form=form)

@app.route('/login_aluno', methods=['GET', 'POST'])
def login_aluno():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        
        aluno = Aluno.query.filter_by(email=email).first()
        if aluno and aluno.verificar_senha(senha):
            if aluno.status == 'inativo':
                flash('Sua conta está inativa. Entre em contato com a administração.')
                return redirect(url_for('login_aluno'))
                
            session['aluno_id'] = aluno.id
            session['aluno_nome'] = aluno.nome
            return redirect(url_for('area_aluno'))
            
        flash('Email ou senha inválidos')
    return render_template('login_aluno.html')

@app.route('/turma/<int:turma_id>/excluir', methods=['POST'])
@admin_required
def excluir_turma(turma_id):
    turma = Turma.query.get_or_404(turma_id)
    try:
        turma.status = 'cancelada'
        db.session.commit()
        flash('Turma cancelada com sucesso!')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao cancelar turma: {str(e)}')
    return redirect(url_for('listar_turmas'))

@app.route('/curso/<int:curso_id>/excluir', methods=['POST'])
@admin_required
def excluir_curso(curso_id):
    curso = Curso.query.get_or_404(curso_id)
    try:
        curso.status = 'inativo'
        db.session.commit()
        flash('Curso inativado com sucesso!')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao inativar curso: {str(e)}')
    return redirect(url_for('listar_cursos'))

@app.route('/aula/<int:aula_id>/excluir', methods=['POST'])
@login_required
def excluir_aula(aula_id):
    aula = Aula.query.get_or_404(aula_id)
    turma_id = aula.turma_id
    try:
        db.session.delete(aula)
        db.session.commit()
        flash('Aula excluída com sucesso!')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao excluir aula: {str(e)}')
    return redirect(url_for('listar_aulas', turma_id=turma_id))

if __name__ == '__main__':
    with app.app_context():
        # Não cria mais as tabelas automaticamente
        # db.create_all()  # Comentado para usar migrações
        criar_usuario_inicial()
    app.run(debug=True) 