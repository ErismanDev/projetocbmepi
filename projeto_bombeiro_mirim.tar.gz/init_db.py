from app import app, db, Usuario, Aluno, Atividade, Participacao, Curso, Turma, generate_password_hash
from datetime import datetime, timedelta

def init_db():
    with app.app_context():
        # Cria todas as tabelas
        db.create_all()

        # Cria usuário admin se não existir
        if not Usuario.query.filter_by(email='admin@bombeiromirim.com').first():
            admin = Usuario(
                nome='Administrador',
                email='admin@bombeiromirim.com',
                senha_hash=generate_password_hash('admin123'),
                tipo='admin'
            )
            db.session.add(admin)

        # Cria um instrutor de exemplo
        if not Usuario.query.filter_by(email='instrutor@bombeiromirim.com').first():
            instrutor = Usuario(
                nome='Instrutor Exemplo',
                email='instrutor@bombeiromirim.com',
                senha_hash=generate_password_hash('instrutor123'),
                tipo='instrutor'
            )
            db.session.add(instrutor)

        # Cria um curso de exemplo
        if not Curso.query.filter_by(nome='Bombeiro Mirim - Turma 2024').first():
            curso = Curso(
                nome='Bombeiro Mirim - Turma 2024',
                descricao='Curso básico de formação de Bombeiro Mirim',
                carga_horaria=120,
                duracao=6,  # Duração em meses
                status='ativo'
            )
            db.session.add(curso)

        # Commit das alterações
        db.session.commit()
        print("Banco de dados inicializado com sucesso!")

if __name__ == '__main__':
    init_db() 